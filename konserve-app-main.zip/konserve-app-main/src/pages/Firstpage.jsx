import React from 'react'
import Navbar from '../components/Navbar'

const Firstpage = () => {
  return (
    <div>
        <Navbar />
    </div>
  )
}

export default Firstpage